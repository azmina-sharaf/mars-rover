/********************************************
Course : TCP1101 Programming Fundamentals
Session: Trimester 2, 2020/21
Assignment: 2
Lecture Section : TC1V
Tutorial Section: TT1V
Name of Student #1 : MOHAMMAD SHAHRULAZWAN BIN MOHD SHAFIRI
ID of Student #1 : 1201302552
Email of Student #1: 1201302552@student.mmu.edu.my
Phone of Student #1: +601128331409
Name of Student #2 : YOGA SHRI A P MURTI 
ID of Student #2 : 1191100796
Email of Student #2: 1191100796@student.mmu.edu.my
Phone of Student #2: +601111420840
Name of Student #3 : AZMINA SHARAF
ID of Student #3 : 1181102970
Email of Student #3: 1181102970@student.mmu.edu.my
Phone of Student #3: +60143203624
********************************************/
#include <iostream>
#include "Map.cpp"
using namespace std;

class Rover
{
private:
    enum Direction
    {
        north = 0,
        east,
        south,
        west
    };
    int x, y, commands = 0, sequences = 0, gold = 0;
    Direction heading;
    char objectUnderRover;
    bool missionAccomplished;
    Map *p_mars; //a pointer to the map for Mars
    Map mapper;  //a map that keeps track of observed cells so far
public:
    Rover(){};
    void land(); //links a map of Mars to a Rover
    bool turnLeft();
    bool turnRight();
    bool move();
    void displayMapper();
    bool executeCommand(char command);
    void initMapper();
    void command(int noGolds);
    void sequence();
    void collectgold();
    char underRover();
    void reset();
    bool win();
    void initP_mars(Map &mars);
};
void Rover::initP_mars(Map &mars)
{
    p_mars = &mars;
}
void Rover::initMapper()
{
    mapper.resize(p_mars->getDimX(), p_mars->getDimY(), '?');
}
void Rover::displayMapper()
{
    switch (heading)
    {
    case 0:
        if (mapper.isInsideMap(x, y + 1))
            mapper.setObject(x, y + 1, p_mars->getObject(x, y + 1));
        if (mapper.isInsideMap(x - 1, y + 1))
            mapper.setObject(x - 1, y + 1, p_mars->getObject(x - 1, y + 1));
        if (mapper.isInsideMap(x + 1, y + 1))
            mapper.setObject(x + 1, y + 1, p_mars->getObject(x + 1, y + 1));

        mapper.display();
        break;
    case 1:
        if (mapper.isInsideMap(x + 1, y))
            mapper.setObject(x + 1, y, p_mars->getObject(x + 1, y));
        if (mapper.isInsideMap(x + 1, y + 1))
            mapper.setObject(x + 1, y + 1, p_mars->getObject(x + 1, y + 1));
        if (mapper.isInsideMap(x + 1, y - 1))
            mapper.setObject(x + 1, y - 1, p_mars->getObject(x + 1, y - 1));

        mapper.display();
        break;
    case 2:
        if (mapper.isInsideMap(x, y - 1))
            mapper.setObject(x, y - 1, p_mars->getObject(x, y - 1));
        if (mapper.isInsideMap(x - 1, y - 1))
            mapper.setObject(x - 1, y - 1, p_mars->getObject(x - 1, y - 1));
        if (mapper.isInsideMap(x + 1, y - 1))
            mapper.setObject(x + 1, y - 1, p_mars->getObject(x + 1, y - 1));

        mapper.display();
        break;
    case 3:
        if (mapper.isInsideMap(x - 1, y))
            mapper.setObject(x - 1, y, p_mars->getObject(x - 1, y));
        if (mapper.isInsideMap(x - 1, y + 1))
            mapper.setObject(x - 1, y + 1, p_mars->getObject(x - 1, y + 1));
        if (mapper.isInsideMap(x - 1, y - 1))
            mapper.setObject(x - 1, y - 1, p_mars->getObject(x - 1, y - 1));

        mapper.display();
        break;

    default:
        break;
    }
}

void Rover::land()
{
    char possibleHeading[4] = {'^', '>', 'v', '<'};
    heading = static_cast<Direction>(rand() % 4);
    char head = possibleHeading[heading];
    x = (p_mars->getDimX() + 1) / 2;
    y = (p_mars->getDimY() + 1) / 2;

    mapper.setObject(x, y, head);
}

bool Rover::turnLeft()
{
    char Heading[] = {'^', '>', 'v', '<'};
    switch (heading)
    {
    case 0:
        heading = west;
        mapper.setObject(x, y, Heading[heading]);
        break;
    case 1:
        heading = north;
        mapper.setObject(x, y, Heading[heading]);
        break;
    case 2:
        heading = east;
        mapper.setObject(x, y, Heading[heading]);
        break;
    case 3:
        heading = south;
        mapper.setObject(x, y, Heading[heading]);
        break;
    }

    return true;
}
bool Rover::turnRight()
{

    char Heading[] = {'^', '>', 'v', '<'};
    switch (heading)
    {
    case 0:
        heading = east;
        mapper.setObject(x, y, Heading[heading]);
        break;
    case 1:
        heading = south;
        mapper.setObject(x, y, Heading[heading]);
        break;
    case 2:
        heading = west;
        mapper.setObject(x, y, Heading[heading]);
        break;
    case 3:
        heading = north;
        mapper.setObject(x, y, Heading[heading]);
        break;
    }
    return true;
}

bool Rover::move()
{

    bool check;
    char Heading[] = {'^', '>', 'v', '<'};
    switch (heading)
    {
    case 0:
        if (!p_mars->isInsideMap(x, y + 1))
        {

            check = false;
            break;
        }
        if (p_mars->isTrap(x, y + 1))
        {
            mapper.setObject(x, y, ' ');
            y += 1;
            mapper.setObject(x, y, 164);
            system("cls");
            mapper.display();

            break;
        }
        if (p_mars->isHill(x, y + 1))
        {
            check = false;
            break;
        }
        else
        {
            mapper.setObject(x, y, ' ');
            y += 1;
            mapper.setObject(x, y, Heading[heading]);
            collectgold();
            check = true;
            break;
        }

    case 1:
        if (!p_mars->isInsideMap(x + 1, y))
        {
            check = false;
            break;
        }
        if (p_mars->isHill(x + 1, y))
        {
            check = false;
            break;
        }
        if (p_mars->isTrap(x + 1, y))
        {
            mapper.setObject(x, y, ' ');
            x += 1;
            mapper.setObject(x, y, 164);
            system("cls");
            mapper.display();
            break;
        }
        else
        {
            mapper.setObject(x, y, ' ');
            x += 1;
            mapper.setObject(x, y, Heading[heading]);
            collectgold();
            check = true;
            break;
        }

    case 2:
        if (!p_mars->isInsideMap(x, y - 1))
        {
            check = false;
            break;
        }
        if (p_mars->isHill(x, y - 1))
        {
            check = false;
            break;
        }
        if (p_mars->isTrap(x, y - 1))
        {
            mapper.setObject(x, y, ' ');
            y -= 1;
            mapper.setObject(x, y, 164);
            system("cls");
            mapper.display();

            break;
        }
        else
        {
            mapper.setObject(x, y, ' ');
            y -= 1;
            mapper.setObject(x, y, Heading[heading]);
            collectgold();
            check = true;
            break;
        }

    case 3:
        if (!p_mars->isInsideMap(x - 1, y))
        {
            check = false;
            break;
        }
        if (p_mars->isHill(x - 1, y))
        {
            check = false;
            break;
        }
        if (p_mars->isTrap(x - 1, y))
        {
            mapper.setObject(x, y, ' ');
            x -= 1;
            mapper.setObject(x, y, 164);
            system("cls");
            mapper.display();
            break;
        }
        else
        {
            mapper.setObject(x, y, ' ');
            x -= 1;
            mapper.setObject(x, y, Heading[heading]);
            collectgold();
            check = true;
            break;
        }

    default:
        check = false;
        break;
    }

    return check;
}

bool Rover::executeCommand(char command)
{

    switch (toupper(command))
    {
    case 'L':
    {
        turnLeft();
        commands += 1;
        return true;
    }
    case 'R':
    {
        turnRight();
        commands += 1;
        return true;
    }
    case 'M':
    {
        if (move())
        {
            commands += 1;
            return true;
        }
        else
        {
            commands += 1;
            return false;
        }
    }
    default:
        return false;
    }
}

void Rover::command(int noGolds)
{

    int score = (gold * 50) - (sequences * 5) - (commands * 1);

    cout << "Mission: Get all the golds!!, Do not get trapped!!\n"
         << "L=Turn Left, R=Turn Right, M=Move, Q=Quit\n"
         << "#=Hill @=Trap *=Gold\n"
         << endl;

    cout << "Total Command Sequences = " << sequences << " [S]\n"
         << "Total Command = " << commands << "[C]\n"
         << "Total Golds = " << gold << "[G] out of " << noGolds << endl
         << "Total Score = [G] x 50 - [S] x 5 -[C] x 1 = " << score << "\n"
         << "\nExample Sequence: MMLMMRMMRMRMLLL" << endl;

    if (gold == noGolds)
    {

        missionAccomplished = true;
    }
    else
    {
        cout << "Enter command sequence => ";
        missionAccomplished = false;
    }
}

void Rover::sequence()
{
    sequences += 1;
}

void Rover::collectgold()
{

    objectUnderRover = p_mars->getObject(x, y);

    if (objectUnderRover == '*')
    {
        gold += 1;
        p_mars->setObject(x, y, ' ');
    }
}

char Rover::underRover()
{
    objectUnderRover = p_mars->getObject(x, y);

    return objectUnderRover;
}

void Rover::reset()
{
    commands = 0;
    sequences = 0;
    gold = 0;
}

bool Rover::win()
{
    if (missionAccomplished)
        return true;
    else
        return false;
}