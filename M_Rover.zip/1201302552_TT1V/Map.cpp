/********************************************
Course : TCP1101 Programming Fundamentals
Session: Trimester 2, 2020/21
Assignment: 2
Lecture Section : TC1V
Tutorial Section: TT1V
Name of Student #1 : MOHAMMAD SHAHRULAZWAN BIN MOHD SHAFIRI
ID of Student #1 : 1201302552
Email of Student #1: 1201302552@student.mmu.edu.my
Phone of Student #1: +601128331409
Name of Student #2 : YOGA SHRI A P MURTI 
ID of Student #2 : 1191100796
Email of Student #2: 1191100796@student.mmu.edu.my
Phone of Student #2: +601111420840
Name of Student #3 : AZMINA SHARAF
ID of Student #3 : 1181102970
Email of Student #3: 1181102970@student.mmu.edu.my
Phone of Student #3: +60143203624
********************************************/ 
#include <iostream>
#include <vector>
#include <iomanip>

using namespace std;

class Map
{
private:
    vector<vector<char>> map;
    int dimX, dimY;

public:
    Map(int dimx =0, int dimy=0);
    ~Map();
    void resize(int dimx, int dimy, char ch);
    void display(int x=0, int y=0);
    void setObject(int x, int y, char ch);
    char getObject(int x, int y);
    bool isEmpty(int x, int y);
    bool isHill(int x, int y);
    bool isTrap(int x, int y);
    bool isGold(int x, int y);
    bool isInsideMap(int x, int y);
    int getDimX() const;
    int getDimY() const;
};

Map::~Map(){
    map.clear();
}

int Map ::getDimX() const
{
    return dimX;
}
int Map ::getDimY() const
{
    return dimY;
}
char Map::getObject(int x, int y)
{
    return map[dimY - y][x - 1];
}
void Map ::setObject(int x, int y, char ch)
{
    map[dimY - y][x - 1] = ch;
}
bool Map::isEmpty(int x, int y)
{
    if (map[dimY - y][x - 1] == ' ')
    {
        return true;
    }
    else
        return false;
}
bool Map::isInsideMap(int x, int y)
{
    
    
    if ((x>=1 && x<=dimX) && (y>=1 && y<=dimY)){
        return true;
    }
    else
        return false;

    
}
Map::Map(int x, int y){
    char objects[] = {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '@', '#'};
    int noOfObjects = 10; //number of objects in the objects array

    dimX = x;
    dimY = y;

    //create dynamic 2D array using vector
    map.resize(dimY); //create rows
    for (int i = 0; i < dimY; ++i)
    {
        map[i].resize(dimX); //resize each rows
    }
    //put random chars into the vector array
    for (int i = 0; i < dimY; ++i)
    {   
        for (int j=0 ; j < dimX; ++j)
        {   
            char check = map[i][j-1];
            if(check=='#'||check=='@'){
                map[i][j]=' ';
            }
            else{
                 int objNo = rand() % noOfObjects;
                 map[i][j] = objects[objNo];
                }
            }
        }
    
}
void Map::display(int x, int y)
{
    //system("cls");
    cout << " --__--__--__--__--__--__--__--_" << endl;
    cout << " = Curiosity, welcome to Mars! =" << endl;
    cout << " __--__--__--__--__--__--__--__-" << endl;
    for (int i = 0; i < dimY; ++i)
    {
        cout << "  ";
        for (int j = 0; j < dimX; ++j)
        {
            cout << "+-";
        }
        cout << "+" << endl;
        cout << setw(2) << (dimY - i);
        for (int j = 0; j < dimX; ++j)
        {
            cout << "|"<< map[i][j];
        }
        cout << "|" << endl;
    }

    cout << "  ";
    for (int j = 0; j < dimX; ++j)
    {
        cout << "+-";
    }
    cout << "+" << endl;

    cout << "  ";
    for (int j = 0; j < dimX; ++j)
    {
        int digit = (j + 1) / 10;
        cout << " ";
        if (digit == 0)
            cout << " ";
        else
            cout << digit;
    }
    cout << endl;

    cout << "  ";
    for (int j = 0; j < dimX; ++j)
    {
        cout << " " << (j + 1) % 10;
    }
    cout << endl;
}

bool Map::isHill(int x, int y){
    if(getObject(x, y)=='#')
        return true;
    else
        return false;
}

bool Map::isTrap(int x, int y){
    if(getObject(x, y)=='@')
        return true;
    else
        return false;
}
bool Map::isGold(int x, int y){
    if(getObject(x, y)=='*')
        return true;
    else
        return false;
}
void Map::resize(int dimx, int dimy, char ch){
    dimX = dimx;
    dimY = dimy;

    map.resize(dimY);
    for (int i = 0; i < dimY; ++i)
    {
        map[i].resize(dimX); 
    }

    for(int i=0; i<dimY; ++i){
        for(int j=0; j<dimX; ++j){
            map[i][j]= ch;
        }
    }
    
}