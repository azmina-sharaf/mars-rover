/********************************************
Course : TCP1101 Programming Fundamentals
Session: Trimester 2, 2020/21
Assignment: 2
Lecture Section : TC1V
Tutorial Section: TT1V
Name of Student #1 : MOHAMMAD SHAHRULAZWAN BIN MOHD SHAFIRI
ID of Student #1 : 1201302552
Email of Student #1: 1201302552@student.mmu.edu.my
Phone of Student #1: +601128331409
Name of Student #2 : YOGA SHRI A P MURTI 
ID of Student #2 : 1191100796
Email of Student #2: 1191100796@student.mmu.edu.my
Phone of Student #2: +601111420840
Name of Student #3 : AZMINA SHARAF
ID of Student #3 : 1181102970
Email of Student #3: 1181102970@student.mmu.edu.my
Phone of Student #3: +60143203624
********************************************/

#include <iostream>
#include <ctime>
#include <cstring>
#include <conio.h>
#include <Windows.h>
#include "Rover.cpp"
#include "startscreen.cpp"
using namespace std;

void login();
void init_map(int x, int y, int noGolds, char gold, Map &mars);
void menu(int &x, int &y, int &noGolds);
void gameSetup(bool &invalidout, bool &invalid, int &x, int &y, int noGolds, char gold, string command, Rover &curiosity, char choice);
void inGame(Rover &curiosity, string &command, int &x, int &y, int &noGolds);

int main()
{
    srand(time(NULL));
    login();
    system("cls");

    int x, y, noGolds;
    char gold = '*';
    string command;
    char choice;
    bool outLoop = true;
    bool insideLoop = true;
    

    Rover curiosity;

    menu(x, y, noGolds);

    gameSetup(outLoop, insideLoop, x, y, noGolds, gold, command, curiosity, choice);
    
    return 0;
}




void init_map(int x, int y, int noGolds, char gold, Map &mars)
{
    int rx = (x + 1) / 2;
    int ry = (y + 1) / 2;
    int spwanx = 0;
    int spwany = 0;

    mars.setObject(rx, ry, ' ');
    for (int i = 0; i < noGolds; i++)
    {

        spwanx = rand() % x + 1;
        spwany = rand() % y + 1;

        while (!mars.isInsideMap(spwanx, spwany))
        {
            spwanx = rand() % x + 1;
            spwany = rand() % y + 1;
        }

        while ((spwanx == rx) && (spwany == ry))
        {
            spwanx = rand() % x + 1;
            spwany = rand() % y + 1;
        }
        while (!mars.isEmpty(spwanx, spwany))
        {
            spwanx = rand() % x + 1;
            spwany = rand() % y + 1;
        }

        if (mars.isInsideMap(spwanx, spwany - 1) == false)
        {
            if (mars.getObject(spwanx, spwany + 1) == '#' || mars.getObject(spwanx, spwany + 1) == '@')
                mars.setObject(spwanx, spwany + 1, ' ');
        }

        if (mars.isInsideMap(spwanx, spwany + 1) == false)
        {
            if (mars.getObject(spwanx, spwany - 1) == '#' || mars.getObject(spwanx, spwany - 1) == '@')
                mars.setObject(spwanx, spwany - 1, ' ');
        }

        if ((mars.isInsideMap(spwanx, spwany + 1) && mars.getObject(spwanx, spwany + 1) == '#') || (mars.isInsideMap(spwanx, spwany + 1) && mars.getObject(spwanx, spwany + 1) == '@'))
        {
            if ((mars.getObject(spwanx, spwany - 1) == '#') || (mars.getObject(spwanx, spwany - 1) == '@'))
                mars.setObject(spwanx, spwany - 1, ' ');
        }

        if (mars.getObject(rx, ry + 1) == '#' || mars.getObject(rx, ry + 1) == '@')
            if (mars.getObject(rx, ry - 1) == '#' || mars.getObject(rx, ry - 1) == '@')
                mars.setObject(rx, ry - 1, ' ');

        /*         cout << spwanx << ":" << spwany << endl; */
        mars.setObject(spwanx, spwany, gold);
        /*         mars.display(); */
    }
}

void menu(int &x, int &y, int &noGolds)
{   
    system("cls");
    cout << "Let's explore Mars...\n"
         << "Mars dimension X => ";
    cin >> x;
    while (cin.fail())
    {
        cin.clear();
        cin.ignore(256, '\n');
        cout << "Please enter numeric value x => ";
        cin >> x;
    }
    cout << "Mars dimension Y => ";
    cin >> y;
    while (cin.fail())
    {
        cin.clear();
        cin.ignore(256, '\n');
        cout << "Please enter numeric value y => ";
        cin >> y;
    }
    cout << "No of Golds => ";
    cin >> noGolds;
    while (cin.fail())
    {
        cin.clear();
        cin.ignore(256, '\n');
        cout << "Please enter numeric value noGolds => ";
        cin >> noGolds;
    }
}

void inGame(Rover &curiosity, string &command, int &x, int &y, int &noGolds)
{
    do
    {
        system("cls");
        curiosity.displayMapper();
        curiosity.command(noGolds);
        if (curiosity.win())
        {
            cout << "\nCongrat!! Mission ACCOMPLISHED!!" << endl;
            break;
        }

        cin >> command;
        curiosity.displayMapper();

        for (int i = 0; i < command.length(); i++)
        {
            if (toupper(command[i]) == 'Q')
            {
                command = "q";
                break;
            }
            system("cls");
            curiosity.displayMapper();
            cout << "\ncommand = " << static_cast<char>(toupper(command[i])) << "[...]" << endl;
            Sleep(1000);
            if (curiosity.executeCommand(command[i]))
            {
                system("cls");
                curiosity.displayMapper();
                cout << "\ncommand = " << static_cast<char>(toupper(command[i])) << "[Execute]" << endl;
                Sleep(1000);
            }
            else
            {
                system("cls");
                curiosity.displayMapper();
                cout << "\ncommand = " << static_cast<char>(toupper(command[i])) << "[Failed]" << endl;
                Sleep(1000);
            }
            if (curiosity.underRover() == '@')
            {
                cout << "Falling into trap!! Mission FAILED!!\n"
                     << endl;
                Sleep(500);
                break;
            }
        }
        if (curiosity.underRover() == '@')
        {
            break;
        }
        curiosity.sequence();
    } while (toupper(command[0]) != 'Q');
}

void gameSetup(bool &invalidout, bool &invalid, int &x, int &y, int noGolds, char gold, string command, Rover &curiosity, char choice)
{
    while (invalidout)
    {
        Map mars(x, y);
        curiosity.initP_mars(mars);
        curiosity.initMapper();
        init_map(x, y, noGolds, gold, mars);
        curiosity.land();

        inGame(curiosity, command, x, y, noGolds);
        if ((curiosity.underRover() != '@') && !curiosity.win())
        {
            cout << "\nQUITTED!! Mission FAILED!!\n"
                 << endl;
        }
        cout << "\nDo you want to see the Map of the Mars? => ";

        while (invalid)
        {
            cin >> choice;
            if (toupper(choice) == 'Y')
            {
                invalid = false;
                mars.display();
                choice = 'r';
            }
            if (toupper(choice) == 'N')
                invalid = false;

            choice = 'r';
        }

        cout << "\nDo you want to explore Mars again? => ";

        bool choiceExplore = true;

        while (choiceExplore)
        {
            cin >> choice;
            if (toupper(choice) == 'Y')
            {
                curiosity.reset();
                menu(x, y, noGolds);
                choiceExplore = false;
                invalidout = true;
                invalid = true;
                choice = 'r';
            }
            if (toupper(choice) == 'N')
            {
                cout << endl;
                cout <<"Good Bye from Mars!" ;
                Sleep(2000);
                cout << endl;
                invalidout = false;
                choice = 'r';
                choiceExplore = false;
            }
        }
    }
}

void login()
{
    employee_log employee_logObj;
    employee_logObj.log();

    Sleep(1000);

    system("cls");

    cout << "\n\n\n\n\n\n Loading simulation program....." << endl;
    cout << "\n \n"
         << endl;

    Sleep(2500);
}