Welcome to Let’s Explore Mars !

The CyberScience Space Lab Inc. of which you work, had just detected gold on Mars. As the 
lead programmer of the lab, you are given the task to develop a simulation program that tests 
the control of the new Mars Rover in search of golds. 

Please use below given username and password in main.cpp to start using this simulator ...
username = lead_programmer
password = marsrovertcp1101

Thank you for using our simulator !
  
