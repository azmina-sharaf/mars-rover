/********************************************
Course : TCP1101 Programming Fundamentals
Session: Trimester 2, 2020/21
Assignment: 2
Lecture Section : TC1V
Tutorial Section: TT1V
Name of Student #1 : MOHAMMAD SHAHRULAZWAN BIN MOHD SHAFIRI
ID of Student #1 : 1201302552
Email of Student #1: 1201302552@student.mmu.edu.my
Phone of Student #1: +601128331409
Name of Student #2 : YOGA SHRI A P MURTI 
ID of Student #2 : 1191100796
Email of Student #2: 1191100796@student.mmu.edu.my
Phone of Student #2: +601111420840
Name of Student #3 : AZMINA SHARAF
ID of Student #3 : 1181102970
Email of Student #3: 1181102970@student.mmu.edu.my
Phone of Student #3: +60143203624
********************************************/ 
#include <iostream>
#include <fstream>
using namespace std;

class employee_log
{
private:
    string password = "marsrovertcp1101";
    string username = "lead_programmer";
    string user_name;
    string pass_word;
    bool statusAccess;
        
public:
    employee_log()
    {

        statusAccess = 0;
    }

    void log()
    { 
        cout << "        ====-The CyberScience Space Lab Inc. -====      "<< endl;
        Sleep(500);
        cout << "\n----------AUTHORISED ACCESS FOR EMPLOYEES ONLY----------" << endl;
        Sleep(500);
        cout << "\n*****PLEASE ENTER YOUR DESIGNATED LOGIN CREDENTIALS*****" <<endl;
        Sleep(500);
        cout << "\n\nUSERNAME => ";
        cin >> user_name;
        Sleep(350);

        
        if(user_name == username)
        {
            cout << "\n\nPASSWORD => ";
            cin >> pass_word;
            Sleep(350);

            

            if(pass_word == password)
            {
                cout << "\n\nLOGIN SUCCESSFUL"<< endl;
                cin.get();
            }
            else
            {
                cout << "\n\nLOGIN DENIED" << endl;
                Sleep(500);
                system("cls");
                log();
                
            
            }
        }
        else
        {
            cout << "\n\nLOGIN DENIED" << endl;
            Sleep(500);
            system("cls");
            log();
            
        }
    }
    
};



